package com.uah.wheatherstation;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class LoginActivity extends AppCompatActivity {

    String tag = "LoginActivity";
    EditText usernameText, passwordText;
    Button loginButton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        this.usernameText = (EditText) findViewById(R.id.usernameText);
        this.passwordText = (EditText) findViewById(R.id.passwordText);
        this.loginButton = (Button) findViewById(R.id.loginButton);
        getSupportActionBar().hide();
        Log.i(tag, "App iniciada");
    }

    public void loginUser(View view){
        String correctUser = "root";
        String correctPassword = "root";

        if(this.usernameText.getText().toString().equals(correctUser) && this.passwordText.getText().toString().equals(correctPassword)){
            Log.i(tag, "Usuario ha iniciado sesión correctamente");
            Intent i =new Intent(LoginActivity.this, MainActivity.class);
            startActivity(i);
            finish();
        }
        else{
            Log.i(tag, "Usuario ha fallado inicio de sesión");
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setMessage("Los credenciales introducidos no son válidos. Por favor, inténtelo de nuevo.");
            builder.setPositiveButton("Vale", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.cancel();
                }
            });
            AlertDialog loginAlert = builder.create();
            loginAlert.show();
        }

    }

}
